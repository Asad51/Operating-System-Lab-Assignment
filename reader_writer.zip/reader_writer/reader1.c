#include<stdio.h>
#include<unistd.h>
#include<sys/stat.h>
#include<sys/wait.h>
#include<string.h>
#include<fcntl.h>

int main(){
    char *PipeName = "/home/asad/IPC_pipe";
    int fd,fd1,fd2,i;
    char story[1024], ans[1024],writerAns[1024];

    fd = open(PipeName, O_RDONLY);
    read(fd, story, 1024);
    close(fd);

    printf("Hello, I am Process-%d. I have read a funny story. Should I blieve it ?.\n%s",getpid(),story);
    scanf("%s",ans);

    fd1 = open(PipeName, O_WRONLY);
    write(fd1, ans, 1024);
    close(fd1);

    return 0;
}
