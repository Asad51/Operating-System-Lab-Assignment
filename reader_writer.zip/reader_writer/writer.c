#include<stdio.h>
#include<unistd.h>
#include<sys/stat.h>
#include<sys/wait.h>
#include<string.h>
#include<fcntl.h>

int main(){
    char *PipeName = "/home/asad/IPC_pipe";
    int fd,fd1,i;
    char story[1024],ans[1024];

    sprintf(story,"Hi, I am Process-%d. I would like o tell you a story. I will continue writing if you like it. \"Once upon a time there were a frog prince and a butterfly princess. There parents were a Banyan tree and a river.\"\nHave you liked my story?[yes/no]",getpid());
    umask(0);
    mknod(PipeName, S_IFIFO | 0666, 0);

    for(i=1; i<2 ;i++){
        fd = open(PipeName, O_WRONLY);
    	write(fd, story, 1024);
    	close(fd);

        fd1 = open(PipeName, O_RDONLY);
        read(fd1, ans, 1024);
        close(fd1);
        printf("%s\n",ans);
    }

    return 0;
}
